const menu=document.getElementById("menu"),nav=document.getElementById("nav");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const modal=document.getElementById("modal");
function consultar(nombre,precio){
  document.getElementById("modalTitle").textContent=nombre;
  document.getElementById("modalText").textContent=`Has seleccionado ${nombre}. Precio: $${precio.toLocaleString("es-CO")} COP. En una tienda real aquí podrías continuar con una consulta o pedido.`;
  modal.classList.add("active");
}
function cerrar(){modal.classList.remove("active")}
modal.addEventListener("click",e=>{if(e.target===modal)cerrar()});

const messages=document.getElementById("messages"), input=document.getElementById("chatInput");
function add(text,type){const d=document.createElement("div");d.className=type;d.textContent=text;messages.appendChild(d);messages.scrollTop=messages.scrollHeight}
function response(text){
  text=text.toLowerCase();
  if(text.includes("producto")||text.includes("ropa")||text.includes("prenda")) return "Tenemos Camiseta HACATE, Blusa Luna, Top Aura, Falda Venus, Chaqueta HACATE y Set Empower.";
  if(text.includes("precio")||text.includes("cuesta")) return "Los precios van desde $48.000 COP hasta $120.000 COP. El catálogo muestra el precio de cada prenda.";
  if(text.includes("casual")) return "Para un estilo casual puedes elegir la Camiseta HACATE ($55.000 COP) o la Chaqueta HACATE ($120.000 COP).";
  if(text.includes("seguridad")) return "HACATE promueve seguridad digital: no compartas contraseñas, datos bancarios, direcciones ni información personal innecesaria.";
  if(text.includes("ia")||text.includes("inteligencia")) return "Este asistente es un prototipo de IA para orientar sobre productos, precios, estilos y seguridad.";
  if(text.includes("hola")) return "¡Hola! 💜 Bienvenida a HACATE. Estoy aquí para ayudarte.";
  return "Puedo ayudarte con productos, precios, estilos, seguridad digital e información sobre HACATE.";
}
function send(){
  const text=input.value.trim(); if(!text)return;
  add(text,"user"); input.value="";
  setTimeout(()=>add(response(text),"bot"),350);
}
function quick(text){add(text,"user");setTimeout(()=>add(response(text),"bot"),350)}
input.addEventListener("keydown",e=>{if(e.key==="Enter")send()});
document.getElementById("form").addEventListener("submit",e=>{
  e.preventDefault();
  alert("¡Gracias! Esta es una consulta de demostración para el proyecto HACATE.");
  e.target.reset();
});
